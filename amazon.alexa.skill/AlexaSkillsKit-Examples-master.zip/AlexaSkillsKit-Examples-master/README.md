# Alexa Skills Kit Example Code
Alexa Skills Kit example code
- Hi World!
	Simple node.js example for AWS Lambda